import SwiftUI

@main
struct ApriPorteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
